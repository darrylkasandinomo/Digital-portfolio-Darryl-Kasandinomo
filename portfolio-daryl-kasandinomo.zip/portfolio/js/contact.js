// === CONTACT FORM HANDLER ===
(function () {
  const form = document.getElementById('contact-form');
  const successMsg = document.getElementById('form-success');
  if (!form) return;

  form.addEventListener('submit', function (e) {
    e.preventDefault();

    const btn = form.querySelector('.form-submit');
    const originalText = btn.textContent;

    btn.textContent = 'Sending...';
    btn.disabled = true;

    // Simulate sending (replace with real submission logic)
    setTimeout(function () {
      form.style.display = 'none';
      if (successMsg) {
        successMsg.classList.add('show');
      }
    }, 1200);
  });

  // Reset form button
  const resetBtn = document.getElementById('form-reset');
  if (resetBtn) {
    resetBtn.addEventListener('click', function () {
      form.reset();
      form.style.display = '';
      if (successMsg) {
        successMsg.classList.remove('show');
      }
      const btn = form.querySelector('.form-submit');
      if (btn) {
        btn.textContent = 'Send Message';
        btn.disabled = false;
      }
    });
  }
})();
